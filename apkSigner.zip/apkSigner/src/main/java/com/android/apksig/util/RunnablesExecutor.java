/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.apksig.util;

import static java.util.concurrent.TimeUnit.MILLISECONDS;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Phaser;
import java.util.concurrent.ThreadPoolExecutor;

public interface RunnablesExecutor {
    void execute(RunnablesProvider provider);



    static final RunnablesExecutor SINGLE_THREADED = new RunnablesExecutor() {
        @Override
        public void execute(RunnablesProvider p) {
            p.createRunnable().run();
        }
    };

    static final RunnablesExecutor MULTI_THREADED = new RunnablesExecutor() {
        private final int PARALLELISM = Math.min(32, Runtime.getRuntime().availableProcessors());
        private final int QUEUE_SIZE = 4;

        @Override
        public void execute(RunnablesProvider provider) {
            final ExecutorService mExecutor =
                    new ThreadPoolExecutor(PARALLELISM, PARALLELISM,
                            0L, MILLISECONDS,
                            new ArrayBlockingQueue<>(QUEUE_SIZE),
                            new ThreadPoolExecutor.CallerRunsPolicy());

            //多线程同步控制器
            Phaser tasks = new Phaser(1);

            //创建PARALLELISM个任务并行执行
            for (int i = 0; i < PARALLELISM; ++i) {
                Runnable task = new Runnable() {
                    @Override
                    public void run() {
                        //v2签名对应的Runable实现类为ApkSigningBlockUtils#ChunkDigester
                        Runnable r = provider.createRunnable();
                        r.run();
                        //当前线程立即返回下一阶段的序号,并且从Phaser中移出当前线程,其他线程在调用arriveAndAwaitAdvance()时不需要等待当前线程.
                        tasks.arriveAndDeregister();
                    }
                };
                // 线程计数parties +1
                tasks.register();

                mExecutor.execute(task);
            }

            // Waiting for the tasks to complete.
            // 表示当前线程完成当前阶段的任务,等待其他线程完成当前阶段的任务.
            // 等待线程的数量就是tasks.register()注册的数量（即parties的数值），只有调用了parties次 arriveAndDeregister(),才会继续执行后面的代码
            tasks.arriveAndAwaitAdvance();

            mExecutor.shutdownNow();
        }
    };


}
